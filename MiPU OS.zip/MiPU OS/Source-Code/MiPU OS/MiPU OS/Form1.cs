﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPU_OS
{
    public partial class Form1 : Form
    {
        string bootanim = "right";
        public Form1()
        {
            InitializeComponent();
        }

        private void bootanimation_Tick(object sender, EventArgs e)
        {
            if (bootanim == "right")
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X + 5, pictureBox1.Location.Y);
                if (pictureBox1.Location.X > 640)
                {
                    bootanim = "left";
                }
            }
            if (bootanim == "left")
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X - 5, pictureBox1.Location.Y);
                if (pictureBox1.Location.X < 340)
                {
                    bootanim = "right";
                }
            }
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            webBrowser1.Visible = false;
            panel1.Visible = false;
            await Task.Delay(3000);
            pictureBox1.Visible = true;
            bootanimation.Start();
            boot.Start();
            Random random = new Random();
            boot.Interval = random.Next(3300, 6600);
        }

        private void boot_Tick(object sender, EventArgs e)
        {
            bootanimation.Stop();
            boot.Stop();
            tabControl1.SelectTab(1);
            clock.Start();
        }

        private void clock_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToString("HH:mm");
            label4.Text = DateTime.Now.ToString("MM月dd日");
            label6.Text = DateTime.Now.ToString("HH:mm");
            label7.Text = DateTime.Now.ToString("MM月dd日");
            pictureBox2.BackColor = Color.FromArgb(150, 0, 0, 0);
            pictureBox3.BackColor = Color.FromArgb(150, 0, 0, 0);
            pictureBox4.BackColor = Color.FromArgb(150, 0, 0, 0);
            label8.BackColor = Color.FromArgb(150, 0, 0, 0);
            label6.BackColor = Color.FromArgb(150, 0, 0, 0);
            label7.BackColor = Color.FromArgb(150, 0, 0, 0);
            panel1.BackColor = Color.FromArgb(150, 0, 0, 0);
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(2);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (panel1.Visible == false)
            {
                panel1.Visible = true;
                button2.Visible = false;
                button3.Visible = false;
            }
            else
            {
                panel1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            notepad mipunote = new notepad();
            mipunote.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            browser mipuwebs = new browser();
            mipuwebs.Show();
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            webBrowser1.Visible = false;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (button2.Visible == true)
            {
                button2.Visible = false;
                button3.Visible = false;
            }
            else
            {
                button2.Visible = true;
                button3.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            paint miuppaint = new paint();
            miuppaint.Show();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                webBrowser1.Visible = true;
                webBrowser1.Url = new Uri("https://www.google.co.jp/search?q=" + textBox1.Text);
            }
        }
    }
}
