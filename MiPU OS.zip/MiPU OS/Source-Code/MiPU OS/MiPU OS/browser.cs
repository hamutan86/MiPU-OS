﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPU_OS
{
    public partial class browser : Form
    {
        bool mousedown = false;
        private Point offset;
        string url = "";
        public browser()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            mousedown = true;
            offset.X = e.X;
            offset.Y = e.Y;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mousedown = false;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - offset.X, currentScreenPos.Y - offset.Y);
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                url = textBox1.Text;
                if (url.Length > 8)
                {
                    if (url.Substring(0, 7) == "http://")
                    {
                        webBrowser1.Url = new Uri(textBox1.Text);
                    }
                    else if (url.Substring(0, 8) == "https://")
                    {
                        webBrowser1.Url = new Uri(textBox1.Text);
                    }
                    else
                    {
                        webBrowser1.Url = new Uri("https://www.google.co.jp/search?q=" + textBox1.Text);
                    }
                }
                else
                {
                    webBrowser1.Url = new Uri("https://www.google.co.jp/search?q=" + textBox1.Text);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            textBox1.Text = webBrowser1.Url.ToString();
        }

        private void browser_Load(object sender, EventArgs e)
        {
            webBrowser1.Url = new Uri("https://www.google.co.jp");
        }
    }
}
