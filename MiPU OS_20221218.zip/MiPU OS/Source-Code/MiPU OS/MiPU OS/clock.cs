﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPU_OS
{
    public partial class clock : Form
    {
        bool mousedown = false;
        private Point offset;
        int minutes = 0;
        int seconds = 0;
        int stopwatchseconds = 0;
        public clock()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            mousedown = true;
            offset.X = e.X;
            offset.Y = e.Y;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mousedown = false;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - offset.X, currentScreenPos.Y - offset.Y);
            }
        }

        private void clock_Load(object sender, EventArgs e)
        {
            clocks.Start();
            button6.Enabled = false;
        }

        private void clocks_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToString("yyyy年MM月dd日") + Environment.NewLine + DateTime.Now.ToString("HH:mm:ss");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            seconds++;
            if (seconds == 60)
            {
                seconds = 0;
                minutes++;
            }
            label4.Text = minutes.ToString() + "分" + seconds.ToString() + "秒";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            minutes++;
            label4.Text = minutes.ToString() + "分" + seconds.ToString() + "秒";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer.Start();
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            seconds--;
            if (seconds == -1)
            {
                minutes--;
                seconds = 59;
                if (minutes == -1)
                {
                    minutes = 0;
                    seconds = 0;
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    timer.Stop();
                }
            }
            label4.Text = minutes.ToString() + "分" + seconds.ToString() + "秒";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer.Stop();
            seconds = 0;
            minutes = 0;
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            label4.Text = minutes.ToString() + "分" + seconds.ToString() + "秒";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            stopwatch.Start();
            button5.Enabled = false;
            button6.Enabled = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            stopwatch.Stop();
            button5.Enabled = true;
            button6.Enabled = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            stopwatch.Stop();
            stopwatchseconds = 0;
            label5.Text = "0";
            button5.Enabled = true;
            button6.Enabled = false;
        }

        private void stopwatch_Tick(object sender, EventArgs e)
        {
            stopwatchseconds++;
            label5.Text = stopwatchseconds.ToString();
        }
    }
}
