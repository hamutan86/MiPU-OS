﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPU_OS
{
    public partial class Form1 : Form
    {
        string bootanim = "right";
        public Form1()
        {
            InitializeComponent();
        }

        private void bootanimation_Tick(object sender, EventArgs e)
        {
            if (bootanim == "right")
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X + 5, pictureBox1.Location.Y);
                if (pictureBox1.Location.X > 640)
                {
                    bootanim = "left";
                }
            }
            if (bootanim == "left")
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X - 5, pictureBox1.Location.Y);
                if (pictureBox1.Location.X < 340)
                {
                    bootanim = "right";
                }
            }
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            webBrowser1.Visible = false;
            panel1.Visible = false;
            panel2.Visible = false;
            pictureBox2.BackColor = Color.FromArgb(150, 0, 0, 0);
            pictureBox3.BackColor = Color.FromArgb(150, 0, 0, 0);
            label6.BackColor = Color.FromArgb(150, 0, 0, 0);
            label7.BackColor = Color.FromArgb(150, 0, 0, 0);
            panel1.BackColor = Color.FromArgb(150, 0, 0, 0);
            panel2.BackColor = Color.FromArgb(150, 0, 0, 0);
            await Task.Delay(3000);
            pictureBox1.Visible = true;
            bootanimation.Start();
            boot.Start();
            Random random = new Random();
            boot.Interval = random.Next(3300, 6600);
        }

        private void boot_Tick(object sender, EventArgs e)
        {
            bootanimation.Stop();
            boot.Stop();
            tabControl1.SelectTab(1);
            clock.Start();
        }

        private void clock_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToString("HH:mm");
            label4.Text = DateTime.Now.ToString("MM月dd日");
            label6.Text = DateTime.Now.ToString("HH:mm");
            label7.Text = DateTime.Now.ToString("MM月dd日");
            label9.Text = DateTime.Now.ToString("yyyy年MM月dd日") + Environment.NewLine + DateTime.Now.ToString("HH:mm:ss");
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(2);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (panel1.Visible == false)
            {
                panel1.Visible = true;
                button2.Visible = false;
                button3.Visible = false;
            }
            else
            {
                panel1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            notepad mipunote = new notepad();
            mipunote.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            browser mipuwebs = new browser();
            mipuwebs.Show();
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            webBrowser1.Visible = false;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (button2.Visible == true)
            {
                button2.Visible = false;
                button3.Visible = false;
            }
            else
            {
                button2.Visible = true;
                button3.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            paint miuppaint = new paint();
            miuppaint.Show();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                webBrowser1.Visible = true;
                webBrowser1.Url = new Uri("https://www.google.co.jp/search?q=" + textBox1.Text);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (panel2.Visible == false)
            {
                panel2.Visible = true;
            }
            else
            {
                panel2.Visible = false;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (panel2.Visible == false)
            {
                panel2.Visible = true;
            }
            else
            {
                panel2.Visible = false;
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (panel2.Visible == false)
            {
                panel2.Visible = true;
            }
            else
            {
                panel2.Visible = false;
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            pictureBox8.Location = new Point(12, pictureBox8.Location.Y);
            tabControl2.SelectTab(0);
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            pictureBox8.Location = new Point(56, pictureBox8.Location.Y);
            tabControl2.SelectTab(1);
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            notepad mipunote = new notepad();
            mipunote.Show();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            paint miuppaint = new paint();
            miuppaint.Show();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            browser mipuwebs = new browser();
            mipuwebs.Show();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            clock Clock = new clock();
            Clock.Show();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            todo Todo = new todo();
            Todo.Show();
        }

        private void menuanim_Tick(object sender, EventArgs e)
        {
            
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            calculator Calculator = new calculator();
            Calculator.Show();
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            screenshot ScreenCapture = new screenshot();
            ScreenCapture.Show();
        }
    }
}
