﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace MiPU_OS
{
    public partial class paint : Form
    {
        bool mousedown = false;
        private Point offset;
        ArrayList listOfPoint;
        bool PencilDown;
        public paint()
        {
            InitializeComponent();
            listOfPoint = new ArrayList();
            PencilDown = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            mousedown = true;
            offset.X = e.X;
            offset.Y = e.Y;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mousedown = false;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - offset.X, currentScreenPos.Y - offset.Y);
            }
        }

        private void paint_MouseDown(object sender, MouseEventArgs e)
        {
            Point p = new Point(e.X, e.Y);
            listOfPoint.Add(p);
            PencilDown = true;
        }

        private void paint_MouseUp(object sender, MouseEventArgs e)
        {
            PencilDown = false;
        }

        private void paint_MouseMove(object sender, MouseEventArgs e)
        {
            Graphics g = CreateGraphics();
            Point points = new Point(e.X, e.Y);
            if (comboBox1.Text == "黒")
            {
                Pen pencil = new Pen(Color.Black);
                if (PencilDown)
                {
                    if (listOfPoint.Count > 1)
                        g.DrawLine(pencil, (Point)listOfPoint[listOfPoint.Count - 1], points);
                    listOfPoint.Add(points);
                }
            }
            if (comboBox1.Text == "赤")
            {
                Pen pencil = new Pen(Color.Red);
                if (PencilDown)
                {
                    if (listOfPoint.Count > 1)
                        g.DrawLine(pencil, (Point)listOfPoint[listOfPoint.Count - 1], points);
                    listOfPoint.Add(points);
                }
            }
            if (comboBox1.Text == "青")
            {
                Pen pencil = new Pen(Color.Blue);
                if (PencilDown)
                {
                    if (listOfPoint.Count > 1)
                        g.DrawLine(pencil, (Point)listOfPoint[listOfPoint.Count - 1], points);
                    listOfPoint.Add(points);
                }
            }
            if (comboBox1.Text == "緑")
            {
                Pen pencil = new Pen(Color.Green);
                if (PencilDown)
                {
                    if (listOfPoint.Count > 1)
                        g.DrawLine(pencil, (Point)listOfPoint[listOfPoint.Count - 1], points);
                    listOfPoint.Add(points);
                }
            }
            if (comboBox1.Text == "黄")
            {
                Pen pencil = new Pen(Color.Yellow);
                if (PencilDown)
                {
                    if (listOfPoint.Count > 1)
                        g.DrawLine(pencil, (Point)listOfPoint[listOfPoint.Count - 1], points);
                    listOfPoint.Add(points);
                }
            }
        }

        private void paint_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedItem = "黒";
        }
    }
}
